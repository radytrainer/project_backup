$(document).ready(function() {
    getRecipe();
    $('#recipe').on('change', function() {
        var select = $('#recipe').val();
         eachRecipe(select);
    });
});

var getRecipe = () => {
    
    $.ajax({
        dataType: 'json',
        url: getUrl(),
        success: (data) => displayRecipe(data),
        error: () => console.log("error")
    });

}

function getUrl() {
    var url = "https://raw.githubusercontent.com/radytrainer/test-api/master/test.json";
    return url;
}

function displayRecipe(myRecipe) {
    var select = "";
    myRecipe.recipes.forEach(item => {
        select += `<option value="${item.id}">${item.name}</option>`;
    });
    $('#recipe').append(select);
}

function eachRecipe(recipe) {
    switch(parseInt(recipe)) {
        case 0:
            getAvocado();
            break;
        case 1:
            getFrenchCrep();
            break;
    }
}

function getAvocado() {
    $.getJSON(
        getUrl(),
        function(data) {
            var result = "";
            data.recipes.forEach( item=> {
                if(item.id === 0) {
                    addMemberHTML(item.nbGuests);
                    showRecipe(item.name, item.iconUrl);
                    stepCook(item.instructions);
                    item.ingredients.forEach(el => {
                        result += `
                        <tr>
                            <td><img src="${el.iconUrl}" width="50"></td>
                            <td>${el.name}</td>
                            <td>${el.quantity}</td>
                            <td>${el.unit[0]}</td>
                        </tr>
                        `;
                    })
                }
            });
            $('#ingredient').html(result);
        }
    )
}
function updateAvocado(member) {
    $.getJSON(
        getUrl(),
        function(data) {
            var result = "";
            data.recipes.forEach( item=> {
                if(item.id === 0) {
                    addMemberHTML(item.nbGuests);
                    showRecipe(item.name, item.iconUrl);
                    stepCook(item.instructions);
                    item.ingredients.forEach(el => {
                        result += `
                        <tr>
                            <td><img src="${el.iconUrl}" width="50"></td>
                            <td>${el.name}</td>
                            <td>${el.quantity * member}</td>
                            <td>${el.unit[0]}</td>
                        </tr>
                        `;
                    })
                }
            });
            $('#ingredient').html(result);
        }
    )
}

function getFrenchCrep() {
    $.getJSON(
        getUrl(),
        function(data) {
            var result = "";
            data.recipes.forEach( item=> {
                if(item.id === 1) {
                    addMemberHTML(item.nbGuests);
                    showRecipe(item.name, item.iconUrl);
                    stepCook(item.instructions);
                    item.ingredients.forEach(el => {
                        result += `
                        <tr>
                            <td><img src="${el.iconUrl}" width="50"></td>
                            <td>${el.name}</td>
                            <td>${el.quantity}</td>
                            <td>${el.unit[0]}</td>
                        </tr>
                        `;
                    })
                }
            });
            $('#ingredient').html(result);
        }
    )
}
function updateFrenchCrep(member) {
    $.getJSON(
        getUrl(),
        function(data) {
            var result = "";
            data.recipes.forEach( item=> {
                if(item.id === 1) {
                    addMemberHTML(item.nbGuests);
                    showRecipe(item.name, item.iconUrl);
                    stepCook(item.instructions);
                    item.ingredients.forEach(el => {
                        result += `
                        <tr>
                            <td><img src="${el.iconUrl}" width="50"></td>
                            <td>${el.name}</td>
                            <td>${el.quantity * member}</td>
                            <td>${el.unit[0]}</td>
                        </tr>
                        `;
                    })
                }
            });
            $('#ingredient').html(result);
        }
    )
}
// Add memeber html
function addMemberHTML (guest) {
    var addmember = `
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <button class="btn btn-primary" type="button" id="minus" onclick="decrease()">&minus;</button>
            </div>
            <input type="number" class="form-control text-center" value="${guest}" disabled id="member" max="15"
                min="0">
            <div class="input-group-append">
                <button class="btn btn-success" type="button" id="add" onclick="increase()">&#x2b;</button>
            </div>
        </div>
    `;
    $('#add-member').html(addmember);
}

function increase() {
    var member = $('#member').val();
    var add = parseInt(member) + 1;
    if( add <= 15) {
        $('#member').val(add);
       // updateAvocado(add);
    }
}

function decrease(member) {
    var member = $('#member').val();
    var minus = parseInt(member) - 1;
    if(minus > 0) {
        $('#member').val(minus);
       // updateFrenchCrep(minus);
    }
}

function showRecipe(name, img) {
    show = "";
    show += `
       <div class="mb-5">
       <img src="${img}" width="150">
       ${name}
       </div>
    `;
    $('#each-recipe').html(show);
}

function stepCook(step) {
    var list = "";
    var eachStep = step.split('<step>');
    for(let i = 1; i  < eachStep.length; i++) {
        list += `
            <li class="list-group-item"><strong class="text-primary">Step ${i}: </strong>${eachStep[i]}</li>
        `;
    }
    $('#step').html(list);
}