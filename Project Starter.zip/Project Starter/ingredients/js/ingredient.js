// API Link
function getUrl() {
    var url = "https://raw.githubusercontent.com/radytrainer/test-api/master/test.json";
    return url;
}
// jQuery start
$(document).ready(function() {
    requestApi();
});

// request api
function requestApi() {
    $.ajax({
        dataType: 'json',
        url: getUrl(),
        success: (data) => getRecipe(data),
        error: () => console.log("Cannot request data"),
    });
}
// get recipe 
function getRecipe(myData) {
    myData.recipes.forEach(item => {
      // get recipe here: item.name ...
        switch(item.id) {
            case 0:
                eachRecipe(item.iconUrl,item.name, 'recipe-one');
                eachGuest(item.nbGuests, 'guest-one', 'primary');
                break;
            case 1:
                eachRecipe(item.iconUrl,item.name, 'recipe-two');
                eachGuest(item.nbGuests, 'guest-two','success');
                break;
            
        }
      // ingredient array
      getIngredient(item.ingredients, item.id);
      
    })
}
function getIngredient(ing, recipeId) {
    ing.forEach(item => {
        switch(recipeId) {
            case 0:
                eachIngredient(item, "recipe-one-ingredient");
                break;
            case 1:
                eachIngredient(item, "recipe-two-ingredient");
                break;
        }
    })
}
// get ingredient of each
function eachIngredient(ingredient, elementId) {
    var eachIng = "";
    eachIng += `
        <tr>
            <td><img src="${ingredient.iconUrl}" width="50"></td>
            <td>${ingredient.name}</td>
            <td>${ingredient.quantity}</td>
            <td>${ingredient.unit[0]}</td>
        </tr>
    `;
    $('#' + elementId).append(eachIng);
}

// each recipe
function eachRecipe(recipe, name, elementId) {
    eachRec = "";
    eachRec += `
        <img src="${recipe}" width="100" height="100" class="rounded-circle">
        <strong>${name}</strong>
    `;
    $('#' + elementId).html(eachRec);
}

// each guest
function eachGuest(myGuest, elementId, color) {
    guest = "";
    guest += `
        <div class="alert alert-${color}">
            <span>សម្រាប់ភ្ញៀវចំនួន ${myGuest}​ នាក់</span>
        </div>
    `;
    $('#' + elementId).html(guest);
}