
function getUrl() {
    var url = "https://raw.githubusercontent.com/radytrainer/test-api/master/test.json";
    return url;
}

$(document).ready(function () {
    requestApi();
    $('#recipe').on('change', () => {
        var recipes = $('#recipe').val();
        getRecipe(recipes);
    })
});

function requestApi() {
    $.ajax({
        dataType: 'json',
        url: getUrl(),
        success: (data) => chooseRecipe(data.recipes),
        error: () => console.log("Cannot get data"),
    });
}
function chooseRecipe(recipe) {
    var option = "";
    recipe.forEach(item=>{
        option += `<option value="${item.id}">${item.name}</option>`;
    });
    $('#recipe').append(option);
}
function getRecipe(recipeId) {
    console.log(recipeId);
}