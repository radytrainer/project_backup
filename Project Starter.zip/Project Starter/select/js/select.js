$(document).ready( () => {
    $('#recipe').on('change', () => {
        var fruit = $('#recipe').val();
        choose(fruit);
    })
});

var choose = (fruits) => {
    switch(parseInt(fruits)) {
        case 1:
            getApple();
            break;
        case 2:
            getBanana();
            break;
        case 3:
            getCoconut();
            break;
    }
}
// get Apple
var getApple = () => {
    var apple = "I love apple";
    printOut(apple);
}
// get Banana
var getBanana = () => {
    var banana = "I love banana";
    printOut(banana);
}
// get Coconut
var getCoconut = () => {
    var coconut = "I love Coconut";
    printOut(coconut);
}
// print out to html
var printOut = (out) => {
    $('#done').html(out);
}